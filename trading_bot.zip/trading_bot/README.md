# Binance Futures Testnet Trading Bot

A clean, structured Python CLI application for placing orders on the [Binance Futures Testnet (USDT-M)](https://testnet.binancefuture.com). Supports Market, Limit, and Stop-Limit orders with precision rounding, leverage management, full logging, and error handling.

---

## Project Structure

```
trading_bot/
├── bot/
│   ├── __init__.py
│   ├── client.py          # Binance REST client (signing, HTTP, symbol info, leverage)
│   ├── orders.py          # Order payload builder + placement logic
│   ├── validators.py      # Input validation (raises ValueError on bad input)
│   └── logging_config.py  # Rotating file logger + console handler
├── tests/
│   ├── test_validators.py  # 30 validator tests
│   ├── test_symbol_info.py # 9 precision rounding tests
│   └── test_orders.py      # 7 payload-building tests
├── cli.py                  # CLI entry point (argparse + interactive menu)
├── .env.example            # Copy to .env and fill in your credentials
├── logs/
│   └── trading_bot.log     # Auto-created at runtime
├── README.md
└── requirements.txt
```

---

## Setup

### 1. Get Testnet Credentials

1. Visit [https://testnet.binancefuture.com](https://testnet.binancefuture.com)
2. Register / log in with your GitHub account
3. Go to the **API Key** tab → generate a key pair
4. Copy your **API Key** and **Secret Key**

### 2. Install Dependencies

```bash
# Python 3.8+ required
pip install -r requirements.txt
```

### 3. Set Your Credentials

Copy the example file and fill it in:

```bash
cp .env.example .env
# then edit .env and add your keys
```

`.env` file format:
```
BINANCE_API_KEY=your_testnet_api_key_here
BINANCE_API_SECRET=your_testnet_api_secret_here
```

Alternatively, export them as shell environment variables:
```bash
export BINANCE_API_KEY="your_key"
export BINANCE_API_SECRET="your_secret"
```

---

## How to Run

### Place a Market Order

```bash
python cli.py place-order --symbol BTCUSDT --side BUY --type MARKET --qty 0.001
python cli.py place-order --symbol BTCUSDT --side SELL --type MARKET --qty 0.001
```

### Place a Limit Order

```bash
python cli.py place-order --symbol BTCUSDT --side SELL --type LIMIT --qty 0.001 --price 97000
python cli.py place-order --symbol ETHUSDT --side BUY  --type LIMIT --qty 0.01  --price 3200
```

### Place a Stop-Limit Order

```bash
python cli.py place-order \
  --symbol ETHUSDT --side BUY --type STOP_LIMIT \
  --qty 0.01 --price 3200 --stop-price 3180
```

### Set Leverage (default is 5×)

```bash
python cli.py place-order --symbol BTCUSDT --side BUY --type MARKET --qty 0.001 --leverage 10
```

> ⚠️ The bot warns you if leverage exceeds 10×. Default is 5× — a conservative setting that reduces liquidation risk.

### Interactive Menu

```bash
python cli.py menu
```

Prompts for all fields step-by-step with validation and a confirmation screen before submitting.

### Adjust Console Verbosity

```bash
# See every API call and response in the terminal
python cli.py --log-level DEBUG place-order --symbol BTCUSDT --side BUY --type MARKET --qty 0.001
```

---

## Run the Tests

No extra setup needed — tests use Python's built-in `unittest`:

```bash
python -m unittest discover -s tests -v
```

If you have `pytest` installed:
```bash
python -m pytest tests/ -v
```

Expected output: **60 tests, 0 failures.**

---

## Sample Terminal Output

```
────────────────────────────────────────────────────────────
  ORDER REQUEST SUMMARY
────────────────────────────────────────────────────────────
  Symbol     : BTCUSDT
  Side       : BUY
  Type       : MARKET
  Quantity   : 0.001
  Leverage   : 5x
────────────────────────────────────────────────────────────
────────────────────────────────────────────────────────────
  ORDER RESPONSE
────────────────────────────────────────────────────────────
  Order ID      : 4963271895
  Client Ord ID : x-abc123DEF
  Symbol        : BTCUSDT
  Side          : BUY
  Type          : MARKET
  Status        : FILLED
  Orig Qty      : 0.001
  Executed Qty  : 0.001
  Avg Price     : 93412.50000
  Leverage      : 5x
────────────────────────────────────────────────────────────

  ✓  Order placed successfully! (orderId=4963271895)
```

---

## What Happens Before Every Order

The bot automatically does the following before submitting any order:

1. **Clock sync** — fetches Binance server time to correct local clock skew (prevents `-1021` timestamp errors)
2. **Symbol validation** — checks that the symbol exists on the testnet (prevents `-1121` errors)
3. **Precision rounding** — rounds quantity down to the symbol's `stepSize`, and rounds price to `tickSize` (prevents `-1111` filter errors)
4. **Leverage set** — calls `POST /fapi/v1/leverage` with your chosen leverage before the order

---

## Logging

All activity is written to `logs/trading_bot.log` (rotating, max 5 MB × 3 backups).

| Level | What's logged |
|-------|--------------|
| DEBUG | Full request/response bodies |
| INFO  | Order submission, acceptance, clock sync, precision rounding |
| WARNING | Validation errors |
| ERROR | API errors, network failures |

API signatures are always redacted (`***`) in logs — safe to share log files.

---

## Architecture

| Layer | File | Responsibility |
|-------|------|----------------|
| Transport | `bot/client.py` | HMAC signing, HTTP, clock sync, symbol info cache, leverage setter |
| Business logic | `bot/orders.py` | Precision rounding, payload building, `OrderResult` dataclass |
| Validation | `bot/validators.py` | Pure functions; raise `ValueError` on bad input |
| CLI | `cli.py` | argparse commands + interactive menu; loads `.env` automatically |
| Logging | `bot/logging_config.py` | Single setup call; child loggers via `get_logger()` |
| Tests | `tests/` | 60 unit tests, no network required |

---

## Assumptions

- **Testnet only.** Base URL is hardcoded to `https://testnet.binancefuture.com`. To use mainnet change `TESTNET_BASE_URL` in `bot/client.py` — do so at your own risk with real funds.
- **USDT-M perpetual futures only** (FAPI endpoints). Coin-M futures (DAPI) are not supported.
- **No position management.** The bot places orders; it does not track open positions or PnL.
- **Leverage default is 5×** — intentionally conservative. The testnet account default is 20×, which this bot overrides on every order.

---

## Requirements

```
requests>=2.31.0
python-dotenv>=1.0.0
pytest>=7.0.0       # optional, for running tests
```

Python **3.8 or higher** required.
