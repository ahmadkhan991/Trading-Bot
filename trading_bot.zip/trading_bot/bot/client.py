"""
Low-level Binance Futures Testnet REST client.

Responsible for:
  - HMAC-SHA256 request signing
  - Server-time synchronisation (handles clock skew)
  - HTTP session management
  - Symbol info cache (precision, tick size, min notional)
  - Leverage management
  - Logging every request / response / error
"""

from __future__ import annotations

import hashlib
import hmac
import math
import time
import urllib.parse
from typing import Any

import requests

from .logging_config import get_logger

logger = get_logger("client")

TESTNET_BASE_URL = "https://testnet.binancefuture.com"
RECV_WINDOW = 5000  # milliseconds


class BinanceAPIError(Exception):
    """Raised when the Binance API returns an error response."""

    def __init__(self, code: int, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(f"Binance API error {code}: {message}")


class SymbolInfo:
    """Parsed precision and filter data for a single symbol."""

    def __init__(self, raw: dict[str, Any]) -> None:
        self.symbol: str = raw["symbol"]
        self.qty_precision: int = raw.get("quantityPrecision", 3)
        self.price_precision: int = raw.get("pricePrecision", 2)

        # Walk filters for step size and tick size
        self.step_size: float = 0.0
        self.tick_size: float = 0.0
        self.min_notional: float = 0.0

        for f in raw.get("filters", []):
            ft = f.get("filterType", "")
            if ft == "LOT_SIZE":
                self.step_size = float(f.get("stepSize", 0))
            elif ft == "PRICE_FILTER":
                self.tick_size = float(f.get("tickSize", 0))
            elif ft == "MIN_NOTIONAL":
                self.min_notional = float(f.get("notional", 0))

    def round_quantity(self, qty: float) -> float:
        """Round qty down to the nearest valid step size."""
        if self.step_size > 0:
            precision = int(round(-math.log10(self.step_size)))
            factor = 10 ** precision
            return math.floor(qty * factor) / factor
        # Fall back to exchange quantityPrecision
        return round(qty, self.qty_precision)

    def round_price(self, price: float) -> float:
        """Round price to the nearest valid tick size."""
        if self.tick_size > 0:
            precision = int(round(-math.log10(self.tick_size)))
            return round(price, precision)
        return round(price, self.price_precision)


class BinanceClient:
    """
    Thin wrapper around the Binance Futures Testnet REST API.

    Parameters
    ----------
    api_key:    Your testnet API key.
    api_secret: Your testnet API secret.
    base_url:   Override base URL (defaults to testnet).
    timeout:    HTTP request timeout in seconds.
    """

    def __init__(
        self,
        api_key: str,
        api_secret: str,
        base_url: str = TESTNET_BASE_URL,
        timeout: int = 10,
    ) -> None:
        if not api_key or not api_secret:
            raise ValueError("api_key and api_secret must not be empty.")
        self.api_key = api_key
        self.api_secret = api_secret
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({"X-MBX-APIKEY": self.api_key})
        self._time_offset: int = 0          # ms, corrected by sync_time()
        self._symbol_cache: dict[str, SymbolInfo] = {}

    # ------------------------------------------------------------------
    # Public helpers
    # ------------------------------------------------------------------

    def sync_time(self) -> None:
        """Fetch server time and compute clock offset to avoid timestamp errors."""
        data = self._get_public("/fapi/v1/time")
        server_ts = data["serverTime"]
        local_ts = int(time.time() * 1000)
        self._time_offset = server_ts - local_ts
        logger.info("Clock sync complete. Offset: %d ms", self._time_offset)

    def get_exchange_info(self) -> dict[str, Any]:
        """Return raw exchange info (symbols, filters, etc.)."""
        return self._get_public("/fapi/v1/exchangeInfo")

    def get_symbol_info(self, symbol: str) -> SymbolInfo:
        """
        Return precision/filter info for *symbol*, fetching once and caching.
        Raises ValueError if symbol does not exist on this exchange.
        """
        symbol = symbol.upper()
        if symbol in self._symbol_cache:
            return self._symbol_cache[symbol]

        info = self.get_exchange_info()
        for s in info.get("symbols", []):
            self._symbol_cache[s["symbol"]] = SymbolInfo(s)

        if symbol not in self._symbol_cache:
            raise ValueError(
                f"Symbol '{symbol}' not found on Binance Futures Testnet. "
                "Check spelling or visit https://testnet.binancefuture.com to see available pairs."
            )
        return self._symbol_cache[symbol]

    def set_leverage(self, symbol: str, leverage: int) -> dict[str, Any]:
        """
        Set leverage for *symbol*.  Safe to call before placing orders.
        """
        logger.info("Setting leverage | symbol=%s leverage=%dx", symbol, leverage)
        return self._post_signed("/fapi/v1/leverage", {"symbol": symbol, "leverage": leverage})

    def get_account(self) -> dict[str, Any]:
        """Return account information (balances, positions)."""
        return self._get_signed("/fapi/v2/account")

    # ------------------------------------------------------------------
    # Order endpoints
    # ------------------------------------------------------------------

    def place_order(self, params: dict[str, Any]) -> dict[str, Any]:
        """
        POST /fapi/v1/order — place a new futures order.

        ``params`` should contain the raw Binance order fields
        (symbol, side, type, quantity, price, …).
        """
        return self._post_signed("/fapi/v1/order", params)

    # ------------------------------------------------------------------
    # Internal request helpers
    # ------------------------------------------------------------------

    def _get_public(self, path: str, params: dict | None = None) -> Any:
        url = self.base_url + path
        logger.debug("GET %s | params=%s", url, params)
        try:
            resp = self._session.get(url, params=params, timeout=self.timeout)
            return self._handle_response(resp)
        except requests.RequestException as exc:
            logger.error("Network error on GET %s: %s", path, exc)
            raise

    def _get_signed(self, path: str, params: dict | None = None) -> Any:
        params = params or {}
        params = self._sign(params)
        url = self.base_url + path
        logger.debug("GET (signed) %s | params=%s", url, self._redact(params))
        try:
            resp = self._session.get(url, params=params, timeout=self.timeout)
            return self._handle_response(resp)
        except requests.RequestException as exc:
            logger.error("Network error on signed GET %s: %s", path, exc)
            raise

    def _post_signed(self, path: str, params: dict) -> Any:
        params = self._sign(params)
        url = self.base_url + path
        logger.info("POST (signed) %s | body=%s", url, self._redact(params))
        try:
            resp = self._session.post(url, data=params, timeout=self.timeout)
            return self._handle_response(resp)
        except requests.RequestException as exc:
            logger.error("Network error on signed POST %s: %s", path, exc)
            raise

    # ------------------------------------------------------------------
    # Signing
    # ------------------------------------------------------------------

    def _sign(self, params: dict) -> dict:
        params["timestamp"] = int(time.time() * 1000) + self._time_offset
        params["recvWindow"] = RECV_WINDOW
        query_string = urllib.parse.urlencode(params)
        signature = hmac.new(
            self.api_secret.encode("utf-8"),
            query_string.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
        params["signature"] = signature
        return params

    # ------------------------------------------------------------------
    # Response handling
    # ------------------------------------------------------------------

    @staticmethod
    def _handle_response(resp: requests.Response) -> Any:
        logger.debug(
            "Response %s | %s | body=%.500s",
            resp.status_code,
            resp.url,
            resp.text,
        )
        try:
            data = resp.json()
        except ValueError:
            resp.raise_for_status()
            return resp.text

        if isinstance(data, dict) and "code" in data and data["code"] != 200:
            # Binance error envelope: {"code": -1121, "msg": "..."}
            raise BinanceAPIError(data["code"], data.get("msg", "Unknown error"))

        resp.raise_for_status()
        return data

    @staticmethod
    def _redact(params: dict) -> dict:
        """Return a copy of params with the signature hidden for logging."""
        p = dict(params)
        if "signature" in p:
            p["signature"] = "***"
        return p
