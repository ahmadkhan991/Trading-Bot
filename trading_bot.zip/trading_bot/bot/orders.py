"""
Order placement logic.

Builds Binance Futures order payloads from validated inputs,
applies symbol-specific precision rounding, delegates to BinanceClient,
and returns a structured OrderResult.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .client import BinanceClient
from .logging_config import get_logger

logger = get_logger("orders")

DEFAULT_LEVERAGE = 5  # conservative default; user can override via --leverage


@dataclass
class OrderRequest:
    symbol: str
    side: str           # BUY | SELL
    order_type: str     # MARKET | LIMIT | STOP_LIMIT
    quantity: float
    price: float | None = None
    stop_price: float | None = None
    time_in_force: str = "GTC"   # Good-Till-Cancelled (required for LIMIT)
    leverage: int = DEFAULT_LEVERAGE


@dataclass
class OrderResult:
    success: bool
    order_id: int | None = None
    client_order_id: str | None = None
    symbol: str | None = None
    side: str | None = None
    order_type: str | None = None
    status: str | None = None
    executed_qty: str | None = None
    avg_price: str | None = None
    orig_qty: str | None = None
    leverage_set: int | None = None
    raw: dict[str, Any] = field(default_factory=dict)
    error: str | None = None


def build_order_payload(req: OrderRequest) -> dict[str, Any]:
    """
    Translate an OrderRequest into the raw Binance API parameter dict.
    Quantities and prices must already be rounded before calling this.
    """
    payload: dict[str, Any] = {
        "symbol": req.symbol,
        "side": req.side,
        "type": _map_order_type(req.order_type),
        "quantity": req.quantity,
    }

    if req.order_type in ("LIMIT", "STOP_LIMIT"):
        payload["timeInForce"] = req.time_in_force
        payload["price"] = req.price

    if req.order_type == "STOP_LIMIT":
        payload["stopPrice"] = req.stop_price

    return payload


def _map_order_type(order_type: str) -> str:
    """Map our internal type names to Binance API type strings."""
    mapping = {
        "MARKET": "MARKET",
        "LIMIT": "LIMIT",
        "STOP_LIMIT": "STOP",
    }
    return mapping.get(order_type.upper(), order_type.upper())


def place_order(client: BinanceClient, req: OrderRequest) -> OrderResult:
    """
    Validate symbol, apply precision rounding, set leverage, then place order.
    Returns an OrderResult regardless of outcome — never raises.
    """
    try:
        # ── 1. Validate symbol exists and get precision rules ──────────
        sym_info = client.get_symbol_info(req.symbol)
        logger.info(
            "Symbol info | %s | step_size=%s tick_size=%s qty_precision=%d price_precision=%d",
            sym_info.symbol, sym_info.step_size, sym_info.tick_size,
            sym_info.qty_precision, sym_info.price_precision,
        )

        # ── 2. Apply precision rounding ────────────────────────────────
        rounded_qty = sym_info.round_quantity(req.quantity)
        if rounded_qty != req.quantity:
            logger.info(
                "Quantity rounded | %s → %s (step_size=%s)",
                req.quantity, rounded_qty, sym_info.step_size,
            )
        req.quantity = rounded_qty

        if req.price is not None:
            rounded_price = sym_info.round_price(req.price)
            if rounded_price != req.price:
                logger.info(
                    "Price rounded | %s → %s (tick_size=%s)",
                    req.price, rounded_price, sym_info.tick_size,
                )
            req.price = rounded_price

        if req.stop_price is not None:
            rounded_stop = sym_info.round_price(req.stop_price)
            if rounded_stop != req.stop_price:
                logger.info("Stop price rounded | %s → %s", req.stop_price, rounded_stop)
            req.stop_price = rounded_stop

        # ── 3. Set leverage ────────────────────────────────────────────
        client.set_leverage(req.symbol, req.leverage)

        # ── 4. Build and submit ────────────────────────────────────────
        payload = build_order_payload(req)
        logger.info(
            "Submitting order | symbol=%s side=%s type=%s qty=%s price=%s stop=%s leverage=%dx",
            req.symbol, req.side, req.order_type,
            req.quantity, req.price, req.stop_price, req.leverage,
        )
        data = client.place_order(payload)
        logger.info(
            "Order accepted | orderId=%s status=%s", data.get("orderId"), data.get("status")
        )
        result = _parse_response(data)
        result.leverage_set = req.leverage
        return result

    except Exception as exc:
        logger.error("Order failed | %s", exc)
        return OrderResult(success=False, error=str(exc))


def _parse_response(data: dict[str, Any]) -> OrderResult:
    return OrderResult(
        success=True,
        order_id=data.get("orderId"),
        client_order_id=data.get("clientOrderId"),
        symbol=data.get("symbol"),
        side=data.get("side"),
        order_type=data.get("type"),
        status=data.get("status"),
        executed_qty=data.get("executedQty"),
        avg_price=data.get("avgPrice"),
        orig_qty=data.get("origQty"),
        raw=data,
    )
