"""
Input validation for trading bot CLI arguments.
All validators raise ValueError with human-readable messages on bad input.
"""

from __future__ import annotations

VALID_SIDES = {"BUY", "SELL"}
VALID_ORDER_TYPES = {"MARKET", "LIMIT", "STOP_LIMIT"}


def validate_symbol(symbol: str) -> str:
    s = symbol.strip().upper()
    if not s or not s.isalnum():
        raise ValueError(
            f"Invalid symbol '{symbol}'. Must be alphanumeric, e.g. BTCUSDT."
        )
    return s


def validate_side(side: str) -> str:
    s = side.strip().upper()
    if s not in VALID_SIDES:
        raise ValueError(
            f"Invalid side '{side}'. Choose from: {', '.join(sorted(VALID_SIDES))}."
        )
    return s


def validate_order_type(order_type: str) -> str:
    t = order_type.strip().upper()
    if t not in VALID_ORDER_TYPES:
        raise ValueError(
            f"Invalid order type '{order_type}'. "
            f"Choose from: {', '.join(sorted(VALID_ORDER_TYPES))}."
        )
    return t


def validate_quantity(quantity: str | float) -> float:
    try:
        q = float(quantity)
    except (ValueError, TypeError):
        raise ValueError(f"Invalid quantity '{quantity}'. Must be a positive number.")
    if q <= 0:
        raise ValueError(f"Quantity must be greater than 0, got {q}.")
    return q


def validate_price(price: str | float | None, order_type: str) -> float | None:
    """
    Price is required for LIMIT and STOP_LIMIT orders.
    Returns None for MARKET orders.
    """
    order_type = order_type.strip().upper()

    if order_type == "MARKET":
        return None  # price is irrelevant for market orders

    if price is None:
        raise ValueError(
            f"Price is required for {order_type} orders. "
            "Provide it with --price."
        )
    try:
        p = float(price)
    except (ValueError, TypeError):
        raise ValueError(f"Invalid price '{price}'. Must be a positive number.")
    if p <= 0:
        raise ValueError(f"Price must be greater than 0, got {p}.")
    return p


def validate_stop_price(
    stop_price: str | float | None, order_type: str
) -> float | None:
    """Stop price is required only for STOP_LIMIT orders."""
    if order_type.upper() != "STOP_LIMIT":
        return None
    if stop_price is None:
        raise ValueError(
            "Stop price is required for STOP_LIMIT orders. "
            "Provide it with --stop-price."
        )
    try:
        sp = float(stop_price)
    except (ValueError, TypeError):
        raise ValueError(f"Invalid stop price '{stop_price}'. Must be a positive number.")
    if sp <= 0:
        raise ValueError(f"Stop price must be greater than 0, got {sp}.")
    return sp


def validate_leverage(leverage: str | int | None) -> int:
    """Leverage must be an integer between 1 and 125."""
    if leverage is None:
        return 5  # safe default
    try:
        lev = int(leverage)
    except (ValueError, TypeError):
        raise ValueError(f"Invalid leverage '{leverage}'. Must be an integer between 1 and 125.")
    if not (1 <= lev <= 125):
        raise ValueError(f"Leverage must be between 1 and 125, got {lev}.")
    return lev
