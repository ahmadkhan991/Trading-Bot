#!/usr/bin/env python3
"""
cli.py — Command-line interface for the Binance Futures Testnet trading bot.

Usage examples
--------------
# Market BUY
python cli.py place-order --symbol BTCUSDT --side BUY --type MARKET --qty 0.001

# Limit SELL
python cli.py place-order --symbol BTCUSDT --side SELL --type LIMIT --qty 0.001 --price 95000

# Stop-Limit BUY
python cli.py place-order --symbol ETHUSDT --side BUY --type STOP_LIMIT \
    --qty 0.01 --price 3200 --stop-price 3180

# Interactive menu
python cli.py menu
"""

from __future__ import annotations

import os
import sys
import argparse

# Load .env file if present (no error if missing)
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # python-dotenv not installed; fall back to real env vars

from bot.client import BinanceClient, BinanceAPIError
from bot.orders import OrderRequest, place_order, DEFAULT_LEVERAGE
from bot.validators import (
    validate_symbol,
    validate_side,
    validate_order_type,
    validate_quantity,
    validate_price,
    validate_stop_price,
    validate_leverage,
)
from bot.logging_config import setup_logging, get_logger

logger = get_logger("cli")

# ──────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────

SEPARATOR = "─" * 60


def _print_sep() -> None:
    print(SEPARATOR)


def _get_client() -> BinanceClient:
    api_key = os.getenv("BINANCE_API_KEY", "").strip()
    api_secret = os.getenv("BINANCE_API_SECRET", "").strip()
    if not api_key or not api_secret:
        print(
            "\n  [ERROR] API credentials not found.\n"
            "\n  Option 1 — create a .env file in this folder:\n"
            "    BINANCE_API_KEY=your_key\n"
            "    BINANCE_API_SECRET=your_secret\n"
            "\n  Option 2 — export environment variables:\n"
            "    export BINANCE_API_KEY='your_key'\n"
            "    export BINANCE_API_SECRET='your_secret'\n"
        )
        sys.exit(1)
    client = BinanceClient(api_key=api_key, api_secret=api_secret)
    client.sync_time()
    return client


def _print_request_summary(req: OrderRequest) -> None:
    _print_sep()
    print("  ORDER REQUEST SUMMARY")
    _print_sep()
    print(f"  Symbol     : {req.symbol}")
    print(f"  Side       : {req.side}")
    print(f"  Type       : {req.order_type}")
    print(f"  Quantity   : {req.quantity}")
    if req.price is not None:
        print(f"  Price      : {req.price}")
    if req.stop_price is not None:
        print(f"  Stop Price : {req.stop_price}")
    print(f"  Leverage   : {req.leverage}x")
    _print_sep()
    if req.leverage > 10:
        print(f"  ⚠  WARNING: Leverage is set to {req.leverage}x. High leverage increases liquidation risk.")
        _print_sep()


def _print_order_result(result) -> None:
    if not result.success:
        print(f"\n  ✗  Order FAILED: {result.error}\n")
        logger.error("Order failed: %s", result.error)
        return

    _print_sep()
    print("  ORDER RESPONSE")
    _print_sep()
    print(f"  Order ID      : {result.order_id}")
    print(f"  Client Ord ID : {result.client_order_id}")
    print(f"  Symbol        : {result.symbol}")
    print(f"  Side          : {result.side}")
    print(f"  Type          : {result.order_type}")
    print(f"  Status        : {result.status}")
    print(f"  Orig Qty      : {result.orig_qty}")
    print(f"  Executed Qty  : {result.executed_qty}")
    if result.avg_price:
        print(f"  Avg Price     : {result.avg_price}")
    if result.leverage_set:
        print(f"  Leverage      : {result.leverage_set}x")
    _print_sep()
    print(f"\n  ✓  Order placed successfully! (orderId={result.order_id})\n")


# ──────────────────────────────────────────────────────────
# Command: place-order (argparse)
# ──────────────────────────────────────────────────────────

def cmd_place_order(args: argparse.Namespace) -> None:
    try:
        symbol     = validate_symbol(args.symbol)
        side       = validate_side(args.side)
        order_type = validate_order_type(args.type)
        quantity   = validate_quantity(args.qty)
        price      = validate_price(args.price, order_type)
        stop_price = validate_stop_price(args.stop_price, order_type)
        leverage   = validate_leverage(args.leverage)
    except ValueError as exc:
        print(f"\n  [VALIDATION ERROR] {exc}\n")
        logger.warning("Validation error: %s", exc)
        sys.exit(1)

    req = OrderRequest(
        symbol=symbol,
        side=side,
        order_type=order_type,
        quantity=quantity,
        price=price,
        stop_price=stop_price,
        leverage=leverage,
    )

    _print_request_summary(req)

    client = _get_client()
    result = place_order(client, req)
    _print_order_result(result)

    if not result.success:
        sys.exit(1)


# ──────────────────────────────────────────────────────────
# Command: menu (interactive)
# ──────────────────────────────────────────────────────────

def _prompt(label: str, default: str | None = None) -> str:
    suffix = f" [{default}]" if default else ""
    val = input(f"  {label}{suffix}: ").strip()
    return val if val else (default or "")


def _prompt_optional(label: str) -> str | None:
    val = input(f"  {label} (optional, press Enter to skip): ").strip()
    return val if val else None


def cmd_menu() -> None:
    print("\n" + SEPARATOR)
    print("   BINANCE FUTURES TESTNET — TRADING BOT")
    print(SEPARATOR)

    try:
        symbol     = validate_symbol(_prompt("Symbol", "BTCUSDT"))
        side       = validate_side(_prompt("Side (BUY/SELL)", "BUY"))
        order_type = validate_order_type(_prompt("Order type (MARKET/LIMIT/STOP_LIMIT)", "MARKET"))
        quantity   = validate_quantity(_prompt("Quantity"))

        price_raw = None
        stop_price_raw = None

        if order_type in ("LIMIT", "STOP_LIMIT"):
            price_raw = _prompt("Limit price")
        if order_type == "STOP_LIMIT":
            stop_price_raw = _prompt("Stop price")

        price      = validate_price(price_raw, order_type)
        stop_price = validate_stop_price(stop_price_raw, order_type)
        leverage   = validate_leverage(_prompt(f"Leverage (1–125, default={DEFAULT_LEVERAGE})", str(DEFAULT_LEVERAGE)))

    except (ValueError, KeyboardInterrupt) as exc:
        print(f"\n  [ERROR] {exc}\n")
        sys.exit(1)

    req = OrderRequest(
        symbol=symbol,
        side=side,
        order_type=order_type,
        quantity=quantity,
        price=price,
        stop_price=stop_price,
        leverage=leverage,
    )

    _print_request_summary(req)
    confirm = input("  Confirm and submit? (yes/no): ").strip().lower()
    if confirm not in ("yes", "y"):
        print("  Cancelled.\n")
        sys.exit(0)

    client = _get_client()
    result = place_order(client, req)
    _print_order_result(result)

    if not result.success:
        sys.exit(1)


# ──────────────────────────────────────────────────────────
# Argument parser
# ──────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="trading_bot",
        description="Binance Futures Testnet trading bot",
    )
    parser.add_argument(
        "--log-level",
        default="WARNING",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Console log verbosity (default: WARNING). File always logs DEBUG.",
    )

    sub = parser.add_subparsers(dest="command", required=True)

    # ---- place-order ----
    po = sub.add_parser("place-order", help="Place a single order non-interactively.")
    po.add_argument("--symbol",     required=True, help="e.g. BTCUSDT")
    po.add_argument("--side",       required=True, help="BUY or SELL")
    po.add_argument("--type",       required=True, help="MARKET, LIMIT, or STOP_LIMIT")
    po.add_argument("--qty",        required=True, type=float, help="Order quantity")
    po.add_argument("--price",      type=float,    default=None, help="Limit price (required for LIMIT/STOP_LIMIT)")
    po.add_argument("--stop-price", type=float,    default=None, dest="stop_price",
                    help="Stop trigger price (required for STOP_LIMIT)")
    po.add_argument("--leverage",   type=int,      default=DEFAULT_LEVERAGE,
                    help=f"Futures leverage 1–125 (default: {DEFAULT_LEVERAGE})")

    # ---- menu ----
    sub.add_parser("menu", help="Interactive order entry wizard.")

    return parser


# ──────────────────────────────────────────────────────────
# Entry point
# ──────────────────────────────────────────────────────────

def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    setup_logging(args.log_level)

    if args.command == "place-order":
        cmd_place_order(args)
    elif args.command == "menu":
        cmd_menu()
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
