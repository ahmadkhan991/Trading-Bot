"""
Unit tests for order payload building in bot/orders.py
Run with: python -m unittest discover -s tests -v
"""

import sys
import os
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from bot.orders import OrderRequest, build_order_payload


class TestBuildOrderPayload(unittest.TestCase):
    def test_market_buy(self):
        req = OrderRequest(symbol="BTCUSDT", side="BUY", order_type="MARKET", quantity=0.001)
        p = build_order_payload(req)
        self.assertEqual(p["type"], "MARKET")
        self.assertEqual(p["side"], "BUY")
        self.assertEqual(p["quantity"], 0.001)
        self.assertNotIn("price", p)
        self.assertNotIn("timeInForce", p)

    def test_limit_sell(self):
        req = OrderRequest(symbol="BTCUSDT", side="SELL", order_type="LIMIT",
                           quantity=0.001, price=97000.0)
        p = build_order_payload(req)
        self.assertEqual(p["type"], "LIMIT")
        self.assertEqual(p["price"], 97000.0)
        self.assertEqual(p["timeInForce"], "GTC")

    def test_stop_limit_buy(self):
        req = OrderRequest(symbol="ETHUSDT", side="BUY", order_type="STOP_LIMIT",
                           quantity=0.01, price=3200.0, stop_price=3180.0)
        p = build_order_payload(req)
        self.assertEqual(p["type"], "STOP")        # Binance uses STOP not STOP_LIMIT
        self.assertEqual(p["price"], 3200.0)
        self.assertEqual(p["stopPrice"], 3180.0)
        self.assertEqual(p["timeInForce"], "GTC")

    def test_market_has_no_timeinforce(self):
        req = OrderRequest(symbol="BTCUSDT", side="BUY", order_type="MARKET", quantity=1)
        p = build_order_payload(req)
        self.assertNotIn("timeInForce", p)

    def test_market_has_no_stopprice(self):
        req = OrderRequest(symbol="BTCUSDT", side="BUY", order_type="MARKET", quantity=1)
        p = build_order_payload(req)
        self.assertNotIn("stopPrice", p)

    def test_custom_time_in_force(self):
        req = OrderRequest(symbol="BTCUSDT", side="BUY", order_type="LIMIT",
                           quantity=0.001, price=90000.0, time_in_force="IOC")
        p = build_order_payload(req)
        self.assertEqual(p["timeInForce"], "IOC")


if __name__ == "__main__":
    unittest.main()
