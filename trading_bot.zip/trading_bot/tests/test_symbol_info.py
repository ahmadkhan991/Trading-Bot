"""
Unit tests for SymbolInfo precision rounding in bot/client.py
Run with: python -m unittest discover -s tests -v
"""

import sys
import os
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from bot.client import SymbolInfo


def _make_raw(step_size="0.001", tick_size="0.10", qty_precision=3, price_precision=2):
    return {
        "symbol": "BTCUSDT",
        "quantityPrecision": qty_precision,
        "pricePrecision": price_precision,
        "filters": [
            {"filterType": "LOT_SIZE",     "stepSize": step_size},
            {"filterType": "PRICE_FILTER", "tickSize": tick_size},
            {"filterType": "MIN_NOTIONAL", "notional": "5"},
        ],
    }


class TestRoundQuantity(unittest.TestCase):
    def test_already_valid(self):
        si = SymbolInfo(_make_raw(step_size="0.001"))
        self.assertEqual(si.round_quantity(0.001), 0.001)

    def test_floors_not_rounds_up(self):
        si = SymbolInfo(_make_raw(step_size="0.001"))
        self.assertEqual(si.round_quantity(0.0019), 0.001)

    def test_larger_qty(self):
        si = SymbolInfo(_make_raw(step_size="0.001"))
        self.assertEqual(si.round_quantity(1.2345), 1.234)

    def test_step_size_1(self):
        si = SymbolInfo(_make_raw(step_size="1"))
        self.assertEqual(si.round_quantity(3.9), 3.0)

    def test_step_size_point_01(self):
        si = SymbolInfo(_make_raw(step_size="0.01"))
        self.assertEqual(si.round_quantity(0.567), 0.56)

    def test_no_step_size_uses_precision(self):
        raw = _make_raw()
        raw["filters"] = []
        si = SymbolInfo(raw)
        self.assertEqual(si.round_quantity(0.12345678), round(0.12345678, 3))


class TestRoundPrice(unittest.TestCase):
    def test_already_valid(self):
        si = SymbolInfo(_make_raw(tick_size="0.10"))
        self.assertEqual(si.round_price(93400.0), 93400.0)

    def test_tick_size_1(self):
        si = SymbolInfo(_make_raw(tick_size="1"))
        self.assertEqual(si.round_price(93400.7), 93401.0)

    def test_no_tick_size_uses_precision(self):
        raw = _make_raw()
        raw["filters"] = []
        si = SymbolInfo(raw)
        self.assertEqual(si.round_price(93400.1234), round(93400.1234, 2))


class TestSymbolInfoParsing(unittest.TestCase):
    def test_parses_symbol_name(self):
        si = SymbolInfo(_make_raw())
        self.assertEqual(si.symbol, "BTCUSDT")

    def test_parses_min_notional(self):
        si = SymbolInfo(_make_raw())
        self.assertEqual(si.min_notional, 5.0)

    def test_missing_filters_defaults_zero(self):
        raw = {"symbol": "BTCUSDT", "quantityPrecision": 3, "pricePrecision": 2, "filters": []}
        si = SymbolInfo(raw)
        self.assertEqual(si.step_size, 0.0)
        self.assertEqual(si.tick_size, 0.0)


if __name__ == "__main__":
    unittest.main()
