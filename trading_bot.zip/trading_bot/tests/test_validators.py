"""
Unit tests for bot/validators.py
Run with: python -m unittest discover -s tests -v
       or: python -m pytest tests/ -v   (if pytest installed)
"""

import sys
import os
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from bot.validators import (
    validate_symbol,
    validate_side,
    validate_order_type,
    validate_quantity,
    validate_price,
    validate_stop_price,
    validate_leverage,
)


class TestValidateSymbol(unittest.TestCase):
    def test_uppercase_conversion(self):
        self.assertEqual(validate_symbol("btcusdt"), "BTCUSDT")

    def test_already_uppercase(self):
        self.assertEqual(validate_symbol("ETHUSDT"), "ETHUSDT")

    def test_strips_whitespace(self):
        self.assertEqual(validate_symbol("  BTCUSDT  "), "BTCUSDT")

    def test_empty_raises(self):
        with self.assertRaises(ValueError):
            validate_symbol("")

    def test_symbol_with_space_raises(self):
        with self.assertRaises(ValueError):
            validate_symbol("BTC USDT")

    def test_symbol_with_hyphen_raises(self):
        with self.assertRaises(ValueError):
            validate_symbol("BTC-USDT")


class TestValidateSide(unittest.TestCase):
    def test_buy_lowercase(self):
        self.assertEqual(validate_side("buy"), "BUY")

    def test_sell_uppercase(self):
        self.assertEqual(validate_side("SELL"), "SELL")

    def test_invalid_long_raises(self):
        with self.assertRaises(ValueError):
            validate_side("LONG")

    def test_invalid_short_raises(self):
        with self.assertRaises(ValueError):
            validate_side("SHORT")

    def test_empty_raises(self):
        with self.assertRaises(ValueError):
            validate_side("")


class TestValidateOrderType(unittest.TestCase):
    def test_market(self):
        self.assertEqual(validate_order_type("market"), "MARKET")

    def test_limit(self):
        self.assertEqual(validate_order_type("LIMIT"), "LIMIT")

    def test_stop_limit(self):
        self.assertEqual(validate_order_type("stop_limit"), "STOP_LIMIT")

    def test_invalid_raises(self):
        with self.assertRaises(ValueError):
            validate_order_type("FOK")


class TestValidateQuantity(unittest.TestCase):
    def test_string_float(self):
        self.assertEqual(validate_quantity("0.001"), 0.001)

    def test_integer(self):
        self.assertEqual(validate_quantity(1), 1.0)

    def test_zero_raises(self):
        with self.assertRaises(ValueError):
            validate_quantity(0)

    def test_negative_raises(self):
        with self.assertRaises(ValueError):
            validate_quantity(-1)

    def test_non_numeric_raises(self):
        with self.assertRaises(ValueError):
            validate_quantity("abc")

    def test_none_raises(self):
        with self.assertRaises(ValueError):
            validate_quantity(None)


class TestValidatePrice(unittest.TestCase):
    def test_market_ignores_price(self):
        self.assertIsNone(validate_price(99999, "MARKET"))

    def test_market_none_price_ok(self):
        self.assertIsNone(validate_price(None, "MARKET"))

    def test_limit_requires_price(self):
        with self.assertRaises(ValueError):
            validate_price(None, "LIMIT")

    def test_limit_valid_price(self):
        self.assertEqual(validate_price("97000", "LIMIT"), 97000.0)

    def test_stop_limit_requires_price(self):
        with self.assertRaises(ValueError):
            validate_price(None, "STOP_LIMIT")

    def test_zero_price_raises(self):
        with self.assertRaises(ValueError):
            validate_price(0, "LIMIT")

    def test_negative_price_raises(self):
        with self.assertRaises(ValueError):
            validate_price(-100, "LIMIT")

    def test_non_numeric_raises(self):
        with self.assertRaises(ValueError):
            validate_price("abc", "LIMIT")


class TestValidateStopPrice(unittest.TestCase):
    def test_market_returns_none(self):
        self.assertIsNone(validate_stop_price(None, "MARKET"))

    def test_limit_returns_none(self):
        self.assertIsNone(validate_stop_price(3000, "LIMIT"))

    def test_stop_limit_requires_stop_price(self):
        with self.assertRaises(ValueError):
            validate_stop_price(None, "STOP_LIMIT")

    def test_stop_limit_valid(self):
        self.assertEqual(validate_stop_price("3180", "STOP_LIMIT"), 3180.0)

    def test_zero_stop_price_raises(self):
        with self.assertRaises(ValueError):
            validate_stop_price(0, "STOP_LIMIT")


class TestValidateLeverage(unittest.TestCase):
    def test_valid_integer(self):
        self.assertEqual(validate_leverage(5), 5)

    def test_valid_string(self):
        self.assertEqual(validate_leverage("10"), 10)

    def test_min_boundary(self):
        self.assertEqual(validate_leverage(1), 1)

    def test_max_boundary(self):
        self.assertEqual(validate_leverage(125), 125)

    def test_zero_raises(self):
        with self.assertRaises(ValueError):
            validate_leverage(0)

    def test_above_max_raises(self):
        with self.assertRaises(ValueError):
            validate_leverage(126)

    def test_non_numeric_raises(self):
        with self.assertRaises(ValueError):
            validate_leverage("high")

    def test_none_returns_default(self):
        self.assertEqual(validate_leverage(None), 5)


if __name__ == "__main__":
    unittest.main()
